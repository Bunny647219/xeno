import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { DollarSign, ShoppingCart, Users, TrendingUp, TrendingDown } from 'lucide-react';
import { DateRange } from '../types';
import { getStatsForDateRange } from '../lib/mockData';
import { formatCurrency, formatNumber, formatPercentage } from '../lib/dateUtils';

interface KPICardsProps {
  dateRange: DateRange;
  tenantId: string;
}

export function KPICards({ dateRange, tenantId }: KPICardsProps) {
  const stats = React.useMemo(() => {
    return getStatsForDateRange(dateRange.startDate, dateRange.endDate, tenantId);
  }, [dateRange.startDate, dateRange.endDate, tenantId]);

  const kpis = [
    {
      title: 'Total Revenue',
      value: formatCurrency(stats.totalRevenue),
      change: stats.revenueChange,
      icon: DollarSign,
      color: 'text-green-600',
    },
    {
      title: 'Total Orders',
      value: formatNumber(stats.totalOrders),
      change: stats.ordersChange,
      icon: ShoppingCart,
      color: 'text-blue-600',
    },
    {
      title: 'Unique Customers',
      value: formatNumber(stats.totalCustomers),
      change: stats.customersChange,
      icon: Users,
      color: 'text-purple-600',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      {kpis.map((kpi) => {
        const isPositive = kpi.change >= 0;
        const TrendIcon = isPositive ? TrendingUp : TrendingDown;
        const trendColor = isPositive ? 'text-green-600' : 'text-red-600';
        
        return (
          <Card key={kpi.title} className="relative overflow-hidden">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                {kpi.title}
              </CardTitle>
              <kpi.icon className={`h-5 w-5 ${kpi.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-medium text-gray-900 mb-2">
                {kpi.value}
              </div>
              <div className="flex items-center text-sm">
                <TrendIcon className={`h-4 w-4 mr-1 ${trendColor}`} />
                <span className={`font-medium ${trendColor}`}>
                  {formatPercentage(kpi.change)}
                </span>
                <span className="text-gray-600 ml-1">from last period</span>
              </div>
            </CardContent>
            
            {/* Subtle background decoration */}
            <div className="absolute top-0 right-0 -mt-4 -mr-4 w-16 h-16 rounded-full bg-gradient-to-br from-gray-100 to-transparent opacity-50" />
          </Card>
        );
      })}
    </div>
  );
}