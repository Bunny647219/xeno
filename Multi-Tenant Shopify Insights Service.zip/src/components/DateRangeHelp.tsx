import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Separator } from './ui/separator';
import { CalendarIcon, Clock, TrendingUp, Info, Lightbulb } from 'lucide-react';

interface DateRangeHelpProps {
  onClose?: () => void;
}

export function DateRangeHelp({ onClose }: DateRangeHelpProps) {
  const presetOptions = [
    { 
      value: 'last7days', 
      label: 'Last 7 Days', 
      description: 'Shows data from the past 7 days including today',
      useCase: 'Best for monitoring recent trends and daily performance'
    },
    { 
      value: 'last30days', 
      label: 'Last 30 Days', 
      description: 'Shows data from the past 30 days including today',
      useCase: 'Ideal for monthly performance analysis and trend identification'
    },
    { 
      value: 'last90days', 
      label: 'Last 90 Days', 
      description: 'Shows data from the past 90 days including today',
      useCase: 'Perfect for quarterly reviews and seasonal pattern analysis'
    },
    { 
      value: 'thisMonth', 
      label: 'This Month', 
      description: 'Shows data from the 1st of current month to today',
      useCase: 'Track progress towards monthly goals and targets'
    },
    { 
      value: 'lastMonth', 
      label: 'Last Month', 
      description: 'Shows complete data for the previous month',
      useCase: 'Compare complete month performance and create reports'
    },
    { 
      value: 'thisYear', 
      label: 'This Year', 
      description: 'Shows data from January 1st to today',
      useCase: 'Annual performance tracking and year-over-year comparisons'
    }
  ];

  const customFeatures = [
    {
      title: 'Quick Select Options',
      description: 'Choose from pre-defined ranges like 60 days, 90 days, 6 months, or 1 year',
      icon: <Clock className="h-5 w-5" />
    },
    {
      title: 'Manual Date Input',
      description: 'Type specific dates directly into the start and end date fields',
      icon: <CalendarIcon className="h-5 w-5" />
    },
    {
      title: 'Calendar Picker',
      description: 'Visual calendar interface with dual-month view for easy date selection',
      icon: <CalendarIcon className="h-5 w-5" />
    },
    {
      title: 'Smart Validation',
      description: 'Automatic validation ensures end date is always after start date',
      icon: <Info className="h-5 w-5" />
    }
  ];

  const tips = [
    'For accurate period comparisons, use the same date range length',
    'Custom ranges longer than 365 days may show aggregated data',
    'Weekend and holiday patterns are more visible in 7-30 day ranges',
    'Use "This Month" vs "Last Month" to track monthly goal progress',
    'Quarterly reviews work best with 90-day ranges'
  ];

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-xl flex items-center gap-2">
              <CalendarIcon className="h-6 w-6" />
              Date Range Selection Guide
            </CardTitle>
            <CardDescription className="mt-2">
              Learn how to effectively use date ranges to analyze your store data
            </CardDescription>
          </div>
          {onClose && (
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          )}
        </div>
      </CardHeader>
      
      <CardContent className="space-y-8">
        {/* Preset Options */}
        <div>
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Preset Date Ranges
          </h3>
          <div className="grid gap-4 md:grid-cols-2">
            {presetOptions.map((preset) => (
              <Card key={preset.value} className="border border-gray-200">
                <CardContent className="pt-4">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-medium">{preset.label}</h4>
                    <Badge variant="outline" className="text-xs">
                      Preset
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{preset.description}</p>
                  <p className="text-xs text-blue-600 bg-blue-50 p-2 rounded">
                    💡 {preset.useCase}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <Separator />

        {/* Custom Range Features */}
        <div>
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <CalendarIcon className="h-5 w-5" />
            Custom Range Features
          </h3>
          <div className="grid gap-4 md:grid-cols-2">
            {customFeatures.map((feature, index) => (
              <div key={index} className="flex gap-3 p-4 border border-gray-200 rounded-lg">
                <div className="text-blue-600 mt-1">
                  {feature.icon}
                </div>
                <div>
                  <h4 className="font-medium mb-1">{feature.title}</h4>
                  <p className="text-sm text-gray-600">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <Separator />

        {/* Tips and Best Practices */}
        <div>
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Lightbulb className="h-5 w-5" />
            Tips & Best Practices
          </h3>
          <div className="space-y-3">
            {tips.map((tip, index) => (
              <div key={index} className="flex gap-3 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <div className="text-yellow-600 mt-0.5">
                  <Lightbulb className="h-4 w-4" />
                </div>
                <p className="text-sm text-gray-700">{tip}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Data Processing Info */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h4 className="font-medium text-blue-900 mb-2 flex items-center gap-2">
            <Info className="h-4 w-4" />
            How Date Ranges Affect Your Data
          </h4>
          <div className="text-sm text-blue-800 space-y-2">
            <p>• <strong>All times are processed in your local timezone</strong></p>
            <p>• <strong>Start dates begin at 00:00:00</strong> (midnight)</p>
            <p>• <strong>End dates include the full day until 23:59:59</strong></p>
            <p>• <strong>Performance metrics are calculated dynamically</strong> based on your selection</p>
            <p>• <strong>Charts and KPIs update automatically</strong> when you change the date range</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}