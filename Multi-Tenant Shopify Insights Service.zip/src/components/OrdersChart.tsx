import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { ChartConfig, ChartContainer, ChartTooltip, ChartTooltipContent } from './ui/chart';
import { Area, AreaChart, ResponsiveContainer, XAxis, YAxis, CartesianGrid } from 'recharts';
import { TrendingUp } from 'lucide-react';
import { DateRange } from '../types';
import { getOrdersOverTime } from '../lib/mockData';
import { formatDate, formatCurrency } from '../lib/dateUtils';

interface OrdersChartProps {
  dateRange: DateRange;
  tenantId: string;
}

const chartConfig = {
  count: {
    label: "Orders",
    color: "hsl(var(--chart-1))",
  },
  revenue: {
    label: "Revenue",
    color: "hsl(var(--chart-2))",
  },
} satisfies ChartConfig;

export function OrdersChart({ dateRange, tenantId }: OrdersChartProps) {
  const data = React.useMemo(() => {
    return getOrdersOverTime(dateRange.startDate, dateRange.endDate, tenantId);
  }, [dateRange.startDate, dateRange.endDate, tenantId]);
  
  // Format data for chart
  const chartData = React.useMemo(() => data.map(item => ({
    date: formatDate(new Date(item.date)),
    fullDate: item.date,
    orders: item.count,
    revenue: item.revenue,
  })), [data]);

  const { totalOrders, totalRevenue } = React.useMemo(() => ({
    totalOrders: data.reduce((sum, item) => sum + item.count, 0),
    totalRevenue: data.reduce((sum, item) => sum + item.revenue, 0)
  }), [data]);

  // Custom tooltip component
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-medium text-gray-900 mb-1">{label}</p>
          <div className="space-y-1">
            <p className="text-sm text-blue-600">
              Orders: <span className="font-medium">{data.orders}</span>
            </p>
            <p className="text-sm text-green-600">
              Revenue: <span className="font-medium">{formatCurrency(data.revenue)}</span>
            </p>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Orders Over Time</span>
          <TrendingUp className="h-5 w-5 text-blue-600" />
        </CardTitle>
        <CardDescription>
          Daily order count and revenue trends
        </CardDescription>
        <div className="flex gap-6 text-sm">
          <div>
            <span className="text-gray-600">Total Orders: </span>
            <span className="font-medium text-blue-600">{totalOrders}</span>
          </div>
          <div>
            <span className="text-gray-600">Total Revenue: </span>
            <span className="font-medium text-green-600">{formatCurrency(totalRevenue)}</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {chartData.length > 0 ? (
          <ChartContainer config={chartConfig}>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorOrders" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--chart-1))" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(var(--chart-1))" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis 
                  dataKey="date" 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: '#666', fontSize: 12 }}
                />
                <YAxis 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: '#666', fontSize: 12 }}
                />
                <ChartTooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="orders"
                  stroke="hsl(var(--chart-1))"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorOrders)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </ChartContainer>
        ) : (
          <div className="h-64 flex items-center justify-center text-gray-500">
            <div className="text-center">
              <TrendingUp className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p className="text-lg font-medium">No data available</p>
              <p className="text-sm">Try expanding your date range</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}