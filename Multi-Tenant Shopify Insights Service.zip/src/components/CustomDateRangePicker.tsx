import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Calendar } from './ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Separator } from './ui/separator';
import { CalendarIcon, X, Check } from 'lucide-react';
import { DateRange } from '../types';
import { formatDateFull } from '../lib/dateUtils';

interface CustomDateRangePickerProps {
  dateRange: DateRange | null;
  onDateRangeChange: (range: DateRange | null) => void;
  onClose: () => void;
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CustomDateRangePicker({
  dateRange,
  onDateRangeChange,
  onClose,
  isOpen,
  onOpenChange
}: CustomDateRangePickerProps) {
  const [tempRange, setTempRange] = useState<DateRange | null>(dateRange);
  const [startDateInput, setStartDateInput] = useState(
    dateRange?.startDate ? formatInputDate(dateRange.startDate) : ''
  );
  const [endDateInput, setEndDateInput] = useState(
    dateRange?.endDate ? formatInputDate(dateRange.endDate) : ''
  );

  function formatInputDate(date: Date): string {
    return date.toISOString().split('T')[0];
  }

  function parseInputDate(dateString: string): Date | null {
    try {
      const date = new Date(dateString + 'T00:00:00');
      return isNaN(date.getTime()) ? null : date;
    } catch {
      return null;
    }
  }

  const handleQuickSelect = (days: number) => {
    const endDate = new Date();
    endDate.setHours(23, 59, 59, 999);
    const startDate = new Date(endDate.getTime() - (days - 1) * 24 * 60 * 60 * 1000);
    startDate.setHours(0, 0, 0, 0);
    
    const newRange = { startDate, endDate };
    setTempRange(newRange);
    setStartDateInput(formatInputDate(startDate));
    setEndDateInput(formatInputDate(endDate));
  };

  const handleStartDateInputChange = (value: string) => {
    setStartDateInput(value);
    const date = parseInputDate(value);
    if (date) {
      date.setHours(0, 0, 0, 0);
      setTempRange(prev => prev ? { ...prev, startDate: date } : { startDate: date, endDate: new Date() });
    }
  };

  const handleEndDateInputChange = (value: string) => {
    setEndDateInput(value);
    const date = parseInputDate(value);
    if (date) {
      date.setHours(23, 59, 59, 999);
      setTempRange(prev => prev ? { ...prev, endDate: date } : { startDate: new Date(), endDate: date });
    }
  };

  const handleCalendarSelect = (range: any) => {
    if (range?.from) {
      const startDate = new Date(range.from);
      startDate.setHours(0, 0, 0, 0);
      
      if (range?.to) {
        const endDate = new Date(range.to);
        endDate.setHours(23, 59, 59, 999);
        
        const newRange = { startDate, endDate };
        setTempRange(newRange);
        setStartDateInput(formatInputDate(startDate));
        setEndDateInput(formatInputDate(endDate));
      } else {
        setTempRange({ startDate, endDate: startDate });
        setStartDateInput(formatInputDate(startDate));
        setEndDateInput(formatInputDate(startDate));
      }
    }
  };

  const handleApply = () => {
    if (tempRange?.startDate && tempRange?.endDate) {
      // Validate that start date is before end date
      if (tempRange.startDate <= tempRange.endDate) {
        onDateRangeChange(tempRange);
        onClose();
      }
    }
  };

  const handleCancel = () => {
    setTempRange(dateRange);
    setStartDateInput(dateRange?.startDate ? formatInputDate(dateRange.startDate) : '');
    setEndDateInput(dateRange?.endDate ? formatInputDate(dateRange.endDate) : '');
    onClose();
  };

  const isValidRange = tempRange?.startDate && tempRange?.endDate && tempRange.startDate <= tempRange.endDate;
  const rangeText = isValidRange 
    ? `${formatDateFull(tempRange.startDate)} - ${formatDateFull(tempRange.endDate)}`
    : 'Select date range';

  const quickSelectOptions = [
    { label: 'Last 60 days', days: 60 },
    { label: 'Last 90 days', days: 90 },
    { label: 'Last 6 months', days: 180 },
    { label: 'Last year', days: 365 }
  ];

  return (
    <Popover open={isOpen} onOpenChange={onOpenChange}>
      <PopoverTrigger asChild>
        <Button variant="outline" className="w-60 justify-start text-left">
          <CalendarIcon className="mr-2 h-4 w-4" />
          <span className="truncate">{rangeText}</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="end">
        <Card className="w-full border-0 shadow-none">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg flex items-center justify-between">
              Custom Date Range
              <Button variant="ghost" size="sm" onClick={handleCancel}>
                <X className="h-4 w-4" />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Quick Select Options */}
            <div>
              <Label className="text-sm font-medium mb-3 block">Quick Select</Label>
              <div className="grid grid-cols-2 gap-2">
                {quickSelectOptions.map(option => (
                  <Button
                    key={option.days}
                    variant="outline"
                    size="sm"
                    onClick={() => handleQuickSelect(option.days)}
                    className="text-xs h-8"
                  >
                    {option.label}
                  </Button>
                ))}
              </div>
            </div>

            <Separator />

            {/* Date Input Fields */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="start-date" className="text-sm font-medium">Start Date</Label>
                <Input
                  id="start-date"
                  type="date"
                  value={startDateInput}
                  onChange={(e) => handleStartDateInputChange(e.target.value)}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="end-date" className="text-sm font-medium">End Date</Label>
                <Input
                  id="end-date"
                  type="date"
                  value={endDateInput}
                  onChange={(e) => handleEndDateInputChange(e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>

            <Separator />

            {/* Calendar */}
            <div>
              <Label className="text-sm font-medium mb-3 block">Or select from calendar</Label>
              <Calendar
                mode="range"
                selected={tempRange ? {
                  from: tempRange.startDate,
                  to: tempRange.endDate
                } : undefined}
                onSelect={handleCalendarSelect}
                numberOfMonths={2}
                className="rounded-md border"
              />
            </div>

            {/* Validation Message */}
            {tempRange?.startDate && tempRange?.endDate && tempRange.startDate > tempRange.endDate && (
              <div className="text-sm text-red-600 bg-red-50 p-2 rounded-md">
                End date must be after start date
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={handleCancel}>
                Cancel
              </Button>
              <Button 
                onClick={handleApply}
                disabled={!isValidRange}
                className="flex items-center gap-2"
              >
                <Check className="h-4 w-4" />
                Apply Range
              </Button>
            </div>
          </CardContent>
        </Card>
      </PopoverContent>
    </Popover>
  );
}