import React from 'react';

interface XenoLogoProps {
  size?: number;
  showText?: boolean;
  className?: string;
}

export function XenoLogo({ size = 32, showText = true, className = "" }: XenoLogoProps) {
  const logoSize = size;
  const fontSize = Math.max(16, size * 0.6);

  return (
    <div className={`inline-flex items-center gap-2 ${className}`}>
      <div 
        className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center shadow-sm"
        style={{ width: logoSize, height: logoSize }}
      >
        <svg
          width={size * 0.6}
          height={size * 0.6}
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* X shape */}
          <path
            d="M6 6L18 18M6 18L18 6"
            stroke="white"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* Analytics dots overlay */}
          <circle cx="9" cy="9" r="1.5" fill="rgba(80, 227, 194, 0.8)" />
          <circle cx="15" cy="15" r="1.5" fill="rgba(80, 227, 194, 0.8)" />
          <circle cx="12" cy="12" r="1" fill="white" />
        </svg>
      </div>
      {showText && (
        <span 
          className="text-gray-900 font-medium tracking-tight"
          style={{ fontSize: `${fontSize}px` }}
        >
          Xeno Insights
        </span>
      )}
    </div>
  );
}