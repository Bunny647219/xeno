import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogTrigger } from './ui/dialog';
import { Badge } from './ui/badge';
import { LogOut, TrendingUp, TrendingDown, Users, ShoppingCart, DollarSign, HelpCircle } from 'lucide-react';
import { AuthService } from '../lib/auth';
import { KPICards } from './KPICards';
import { OrdersChart } from './OrdersChart';
import { TopCustomersChart } from './TopCustomersChart';
import { CustomDateRangePicker } from './CustomDateRangePicker';
import { DateRangeHelp } from './DateRangeHelp';
import { DateRange, DateRangePreset } from '../types';
import { getDateRangeForPreset, formatDateFull } from '../lib/dateUtils';
import { XenoLogo } from './XenoLogo';

interface DashboardProps {
  onLogout: () => void;
}

export function Dashboard({ onLogout }: DashboardProps) {
  const [selectedPreset, setSelectedPreset] = useState<DateRangePreset>('last30days');
  const [customDateRange, setCustomDateRange] = useState<DateRange | null>(null);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [showDateRangeHelp, setShowDateRangeHelp] = useState(false);
  
  const user = AuthService.getCurrentUser();
  
  // Performance monitoring for dashboard load
  React.useEffect(() => {
    const startTime = performance.now();
    const timer = setTimeout(() => {
      const endTime = performance.now();
      console.log(`📊 Dashboard fully loaded in ${(endTime - startTime).toFixed(2)}ms`);
    }, 0);
    return () => clearTimeout(timer);
  }, []);
  
  // Get current date range based on preset or custom selection
  const currentDateRange = selectedPreset === 'custom' && customDateRange 
    ? customDateRange 
    : getDateRangeForPreset(selectedPreset);

  const handleLogout = () => {
    AuthService.logout();
    onLogout();
  };

  const handlePresetChange = (preset: DateRangePreset) => {
    setSelectedPreset(preset);
    if (preset !== 'custom') {
      setCustomDateRange(null);
    }
  };

  const handleCustomDateSelect = (range: DateRange | null) => {
    setCustomDateRange(range);
    if (range) {
      setSelectedPreset('custom');
    }
  };

  const formatDateRangeDisplay = () => {
    if (!currentDateRange) return 'Select date range';
    
    if (selectedPreset === 'custom') {
      return `${formatDateFull(currentDateRange.startDate)} - ${formatDateFull(currentDateRange.endDate)}`;
    }
    
    switch (selectedPreset) {
      case 'last7days':
        return 'Last 7 Days';
      case 'last30days':
        return 'Last 30 Days';
      case 'last90days':
        return 'Last 90 Days';
      case 'thisMonth':
        return 'This Month';
      case 'lastMonth':
        return 'Last Month';
      case 'thisYear':
        return 'This Year';
      default:
        return 'Select date range';
    }
  };

  if (!user || !currentDateRange) {
    return <div>Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <XenoLogo size={32} showText={true} />
              <div className="hidden sm:block">
                <Badge variant="outline" className="text-xs">
                  {user.shopDomain}
                </Badge>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <span className="text-sm text-gray-600 hidden sm:inline">
                {user.email}
              </span>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleLogout}
                className="flex items-center gap-2"
              >
                <LogOut className="w-4 h-4" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Date Range Filter */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
            <div>
              <h1 className="text-2xl text-gray-900 mb-2">Analytics Dashboard</h1>
              <p className="text-gray-600">Monitor your store's performance and customer insights</p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-2 ml-auto">
              <div className="flex gap-2">
                <Select value={selectedPreset} onValueChange={handlePresetChange}>
                  <SelectTrigger className="w-44">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="last7days">Last 7 Days</SelectItem>
                    <SelectItem value="last30days">Last 30 Days</SelectItem>
                    <SelectItem value="last90days">Last 90 Days</SelectItem>
                    <SelectItem value="thisMonth">This Month</SelectItem>
                    <SelectItem value="lastMonth">Last Month</SelectItem>
                    <SelectItem value="thisYear">This Year</SelectItem>
                    <SelectItem value="custom">Custom Range</SelectItem>
                  </SelectContent>
                </Select>
                
                <Dialog open={showDateRangeHelp} onOpenChange={setShowDateRangeHelp}>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm" className="px-2">
                      <HelpCircle className="h-4 w-4" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
                    <DateRangeHelp onClose={() => setShowDateRangeHelp(false)} />
                  </DialogContent>
                </Dialog>
              </div>
              
              {selectedPreset === 'custom' && (
                <div className="flex gap-2">
                  <CustomDateRangePicker
                    dateRange={customDateRange}
                    onDateRangeChange={handleCustomDateSelect}
                    onClose={() => setIsCalendarOpen(false)}
                    isOpen={isCalendarOpen}
                    onOpenChange={setIsCalendarOpen}
                  />
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      setCustomDateRange(null);
                      setSelectedPreset('last30days');
                    }}
                    className="text-xs"
                  >
                    Reset
                  </Button>
                </div>
              )}
            </div>
          </div>
          
          <div className="mt-4 flex flex-col sm:flex-row sm:items-center gap-2 text-sm text-gray-600">
            <span>Showing data for: <span className="font-medium">{formatDateRangeDisplay()}</span></span>
            {selectedPreset === 'custom' && currentDateRange && (
              <Badge variant="secondary" className="text-xs w-fit">
                {Math.ceil((currentDateRange.endDate.getTime() - currentDateRange.startDate.getTime()) / (1000 * 60 * 60 * 24))} days
              </Badge>
            )}
          </div>
        </div>

        {/* KPI Cards */}
        <KPICards dateRange={currentDateRange} tenantId={user.tenantId} />
        
        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <OrdersChart dateRange={currentDateRange} tenantId={user.tenantId} />
          <TopCustomersChart dateRange={currentDateRange} tenantId={user.tenantId} />
        </div>

        {/* Additional Insights */}
        <AdditionalMetrics dateRange={currentDateRange} tenantId={user.tenantId} />

        {/* Footer */}
        <footer className="mt-12 pt-8 border-t border-gray-200">
          <div className="text-center text-sm text-gray-600">
            <p>Xeno Insights - Shopify Data Analytics Platform</p>
            <p className="mt-1">Demo Version - Sample data for {user.shopDomain}</p>
          </div>
        </footer>
      </main>
    </div>
  );
}

function AdditionalMetrics({ dateRange, tenantId }: { dateRange: DateRange; tenantId: string }) {
  const orders = React.useMemo(() => {
    const { getOrdersInDateRange } = require('../lib/mockData');
    return getOrdersInDateRange(dateRange.startDate, dateRange.endDate, tenantId);
  }, [dateRange.startDate, dateRange.endDate, tenantId]);

  const { paidOrders, avgOrderValue } = React.useMemo(() => {
    const paid = orders.filter((order: any) => order.financialStatus === 'paid');
    const aov = paid.length > 0 ? paid.reduce((sum: number, order: any) => sum + order.totalPrice, 0) / paid.length : 0;
    return { paidOrders: paid, avgOrderValue: aov };
  }, [orders]);
  
  // Simulate metrics based on time period
  const daysDiff = Math.ceil((dateRange.endDate.getTime() - dateRange.startDate.getTime()) / (1000 * 60 * 60 * 24));
  const isShortTerm = daysDiff <= 7;
  const isMediumTerm = daysDiff <= 30;
  
  const conversionRate = isShortTerm ? 3.8 : isMediumTerm ? 3.2 : 2.9;
  const repeatCustomerRate = isShortTerm ? 28.5 : isMediumTerm ? 24.8 : 21.3;
  
  const conversionChange = isShortTerm ? -0.3 : isMediumTerm ? 1.2 : 2.1;
  const repeatChange = isShortTerm ? 4.2 : isMediumTerm ? 2.1 : -1.1;
  const aovChange = (Math.random() - 0.5) * 20; // Random AOV change

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm">Avg Order Value</CardTitle>
          <DollarSign className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-medium">${avgOrderValue.toFixed(2)}</div>
          <p className="text-xs text-muted-foreground">
            <span className={`inline-flex items-center ${aovChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {aovChange >= 0 ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
              {aovChange >= 0 ? '+' : ''}{aovChange.toFixed(1)}%
            </span>
            {' '}from last period
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm">Conversion Rate</CardTitle>
          <TrendingUp className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-medium">{conversionRate}%</div>
          <p className="text-xs text-muted-foreground">
            <span className={`inline-flex items-center ${conversionChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {conversionChange >= 0 ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
              {conversionChange >= 0 ? '+' : ''}{conversionChange}%
            </span>
            {' '}from last period
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm">Repeat Customers</CardTitle>
          <Users className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-medium">{repeatCustomerRate}%</div>
          <p className="text-xs text-muted-foreground">
            <span className={`inline-flex items-center ${repeatChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {repeatChange >= 0 ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
              {repeatChange >= 0 ? '+' : ''}{repeatChange}%
            </span>
            {' '}from last period
          </p>
        </CardContent>
      </Card>
    </div>
  );
}