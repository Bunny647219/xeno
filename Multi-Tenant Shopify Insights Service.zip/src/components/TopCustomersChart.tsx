import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { ChartConfig, ChartContainer, ChartTooltip, ChartTooltipContent } from './ui/chart';
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, CartesianGrid } from 'recharts';
import { Users, Crown } from 'lucide-react';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { DateRange } from '../types';
import { getTopCustomers } from '../lib/mockData';
import { formatCurrency } from '../lib/dateUtils';

interface TopCustomersChartProps {
  dateRange: DateRange;
  tenantId: string;
}

const chartConfig = {
  totalSpent: {
    label: "Total Spent",
    color: "hsl(var(--chart-3))",
  },
} satisfies ChartConfig;

export function TopCustomersChart({ dateRange, tenantId }: TopCustomersChartProps) {
  const customers = React.useMemo(() => {
    return getTopCustomers(dateRange.startDate, dateRange.endDate, tenantId);
  }, [dateRange.startDate, dateRange.endDate, tenantId]);
  
  // Format data for chart
  const chartData = React.useMemo(() => customers.map((customer, index) => ({
    name: customer.name.split(' ').map(n => n[0]).join(''), // Initials
    fullName: customer.name,
    email: customer.email,
    totalSpent: customer.totalSpent,
    orderCount: customer.orderCount,
    rank: index + 1,
  })), [customers]);

  // Custom tooltip component
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg max-w-64">
          <div className="flex items-center gap-2 mb-2">
            <Avatar className="h-8 w-8">
              <AvatarFallback className="text-xs bg-blue-100 text-blue-700">
                {data.name}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium text-gray-900 text-sm">{data.fullName}</p>
              <p className="text-xs text-gray-600">{data.email}</p>
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-sm text-green-600">
              Total Spent: <span className="font-medium">{formatCurrency(data.totalSpent)}</span>
            </p>
            <p className="text-sm text-blue-600">
              Orders: <span className="font-medium">{data.orderCount}</span>
            </p>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Top Customers</span>
          <Users className="h-5 w-5 text-purple-600" />
        </CardTitle>
        <CardDescription>
          Highest spending customers in this period
        </CardDescription>
      </CardHeader>
      <CardContent>
        {customers.length > 0 ? (
          <div className="space-y-6">
            {/* Chart */}
            <ChartContainer config={chartConfig}>
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={chartData} layout="horizontal" margin={{ top: 10, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis 
                    type="number" 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: '#666', fontSize: 12 }}
                    tickFormatter={(value) => formatCurrency(value)}
                  />
                  <YAxis 
                    type="category"
                    dataKey="name"
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: '#666', fontSize: 12 }}
                    width={40}
                  />
                  <ChartTooltip content={<CustomTooltip />} />
                  <Bar
                    dataKey="totalSpent"
                    fill="hsl(var(--chart-3))"
                    radius={[0, 4, 4, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
            
            {/* Customer List */}
            <div className="space-y-3">
              <h4 className="font-medium text-gray-900">Customer Details</h4>
              <div className="space-y-2">
                {customers.map((customer, index) => (
                  <div 
                    key={customer.email} 
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <Avatar className="h-10 w-10">
                          <AvatarFallback className="bg-blue-100 text-blue-700">
                            {customer.name.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        {index === 0 && (
                          <Crown className="absolute -top-1 -right-1 h-4 w-4 text-yellow-500" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium text-gray-900 text-sm">{customer.name}</p>
                        <p className="text-xs text-gray-600">{customer.email}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-green-600 text-sm">
                        {formatCurrency(customer.totalSpent)}
                      </p>
                      <Badge variant="secondary" className="text-xs">
                        {customer.orderCount} orders
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="h-64 flex items-center justify-center text-gray-500">
            <div className="text-center">
              <Users className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p className="text-lg font-medium">No customers found</p>
              <p className="text-sm">Try expanding your date range</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}