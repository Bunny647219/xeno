import { Tenant, User, Customer, Product, Order, StatsResponse, OrdersOverTimeResponse, TopCustomersResponse } from '../types';

// Mock Tenants
export const mockTenants: Tenant[] = [
  {
    id: 'tenant-1',
    shopifyShopDomain: 'demo-electronics.myshopify.com',
    shopifyAccessToken: 'mock-token-1',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-12-01'),
  },
  {
    id: 'tenant-2', 
    shopifyShopDomain: 'fashion-boutique.myshopify.com',
    shopifyAccessToken: 'mock-token-2',
    createdAt: new Date('2024-02-01'),
    updatedAt: new Date('2024-12-01'),
  }
];

// Mock Users
export const mockUsers: User[] = [
  {
    id: 'user-1',
    email: 'admin@demo-electronics.com',
    passwordHash: 'hashed-password-1',
    tenantId: 'tenant-1',
    tenant: mockTenants[0],
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-12-01'),
  },
  {
    id: 'user-2',
    email: 'owner@fashion-boutique.com',
    passwordHash: 'hashed-password-2',
    tenantId: 'tenant-2',
    tenant: mockTenants[1],
    createdAt: new Date('2024-02-01'),
    updatedAt: new Date('2024-12-01'),
  }
];

// Mock Customers for Tenant 1
export const mockCustomers: Customer[] = [
  {
    id: 'customer-1',
    shopifyCustomerId: 1001,
    email: 'sarah.johnson@email.com',
    firstName: 'Sarah',
    lastName: 'Johnson',
    totalSpent: 2847.50,
    tenantId: 'tenant-1',
    createdAt: new Date('2024-03-15'),
    updatedAt: new Date('2024-12-10'),
  },
  {
    id: 'customer-2',
    shopifyCustomerId: 1002,
    email: 'michael.chen@email.com',
    firstName: 'Michael',
    lastName: 'Chen',
    totalSpent: 1923.75,
    tenantId: 'tenant-1',
    createdAt: new Date('2024-04-20'),
    updatedAt: new Date('2024-12-08'),
  },
  {
    id: 'customer-3',
    shopifyCustomerId: 1003,
    email: 'emma.davis@email.com',
    firstName: 'Emma',
    lastName: 'Davis',
    totalSpent: 1654.25,
    tenantId: 'tenant-1',
    createdAt: new Date('2024-05-10'),
    updatedAt: new Date('2024-12-05'),
  },
  {
    id: 'customer-4',
    shopifyCustomerId: 1004,
    email: 'james.wilson@email.com',
    firstName: 'James',
    lastName: 'Wilson',
    totalSpent: 1432.80,
    tenantId: 'tenant-1',
    createdAt: new Date('2024-06-01'),
    updatedAt: new Date('2024-12-03'),
  },
  {
    id: 'customer-5',
    shopifyCustomerId: 1005,
    email: 'lisa.brown@email.com',
    firstName: 'Lisa',
    lastName: 'Brown',
    totalSpent: 1278.90,
    tenantId: 'tenant-1',
    createdAt: new Date('2024-07-12'),
    updatedAt: new Date('2024-12-01'),
  }
];

// Mock Products
export const mockProducts: Product[] = [
  {
    id: 'product-1',
    shopifyProductId: 2001,
    title: 'Wireless Bluetooth Headphones',
    vendor: 'TechSound',
    price: 129.99,
    tenantId: 'tenant-1',
    createdAt: new Date('2024-01-15'),
    updatedAt: new Date('2024-12-01'),
  },
  {
    id: 'product-2',
    shopifyProductId: 2002,
    title: 'Smart Fitness Watch',
    vendor: 'FitTech',
    price: 249.99,
    tenantId: 'tenant-1',
    createdAt: new Date('2024-02-01'),
    updatedAt: new Date('2024-12-01'),
  },
  {
    id: 'product-3',
    shopifyProductId: 2003,
    title: 'Portable Laptop Stand',
    vendor: 'ErgoWorks',
    price: 79.99,
    tenantId: 'tenant-1',
    createdAt: new Date('2024-02-15'),
    updatedAt: new Date('2024-12-01'),
  }
];

// Lazy-loaded mock orders cache
let _mockOrdersCache: Order[] | null = null;

// Generate mock orders with realistic date distribution (lazy-loaded)
const generateMockOrders = (): Order[] => {
  // Return cached orders if available
  if (_mockOrdersCache) {
    return _mockOrdersCache;
  }

  const startTime = performance.now();
  console.log('🏗️ Generating mock orders...'); // Debug log
  const orders: Order[] = [];
  const now = new Date();
  const customersPool = mockCustomers;
  
  // Generate orders for the last 90 days with more realistic distribution
  for (let i = 0; i < 90; i++) {
    const orderDate = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
    
    // More recent days have more orders (simulate growing business)
    let baseOrderCount = 3;
    if (i < 7) baseOrderCount = 8; // Last 7 days: 8-12 orders
    else if (i < 30) baseOrderCount = 5; // Last 30 days: 5-9 orders
    else baseOrderCount = 2; // Older: 2-6 orders
    
    const orderCount = Math.floor(Math.random() * 5) + baseOrderCount;
    
    for (let j = 0; j < orderCount; j++) {
      const customer = customersPool[Math.floor(Math.random() * customersPool.length)];
      
      // Price variation based on recency (higher AOV recently)
      let basePriceMin = 50;
      let basePriceMax = 450;
      if (i < 7) {
        basePriceMin = 80;
        basePriceMax = 500;
      } else if (i < 30) {
        basePriceMin = 60;
        basePriceMax = 400;
      }
      
      const basePrice = Math.random() * (basePriceMax - basePriceMin) + basePriceMin;
      
      // Random hour between 8 AM and 10 PM
      const randomHour = Math.floor(Math.random() * 14) + 8;
      const randomMinute = Math.floor(Math.random() * 60);
      const orderDateTime = new Date(orderDate);
      orderDateTime.setHours(randomHour, randomMinute, 0, 0);
      
      orders.push({
        id: `order-${i}-${j}`,
        shopifyOrderId: 3000 + (i * 10) + j,
        totalPrice: Math.round(basePrice * 100) / 100,
        financialStatus: Math.random() > 0.05 ? 'paid' : 'pending', // 95% paid
        orderCreatedAt: orderDateTime,
        customerId: customer.id,
        customer: customer,
        tenantId: 'tenant-1',
        createdAt: orderDateTime,
        updatedAt: orderDateTime,
      });
    }
  }
  
  // Cache the generated orders
  _mockOrdersCache = orders.sort((a, b) => b.orderCreatedAt.getTime() - a.orderCreatedAt.getTime());
  
  const endTime = performance.now();
  console.log(`✅ Generated ${_mockOrdersCache.length} mock orders in ${(endTime - startTime).toFixed(2)}ms`);
  
  return _mockOrdersCache;
};

// Getter function for orders (lazy-loaded)
export const getMockOrders = (): Order[] => {
  return generateMockOrders();
};

// Debug function to check order distribution
export const debugOrderDistribution = () => {
  const orders = getMockOrders(); // Use lazy-loaded orders
  const now = new Date();
  const last7Days = orders.filter(o => {
    const daysDiff = Math.floor((now.getTime() - o.orderCreatedAt.getTime()) / (1000 * 60 * 60 * 24));
    return daysDiff < 7 && o.financialStatus === 'paid';
  });
  
  const last30Days = orders.filter(o => {
    const daysDiff = Math.floor((now.getTime() - o.orderCreatedAt.getTime()) / (1000 * 60 * 60 * 24));
    return daysDiff < 30 && o.financialStatus === 'paid';
  });
  
  console.log('Debug: Last 7 days orders:', last7Days.length);
  console.log('Debug: Last 30 days orders:', last30Days.length);
  console.log('Debug: Total orders:', orders.length);
};

// Cache for expensive computations
const _dateRangeCache = new Map<string, Order[]>();

// Helper functions for data filtering with caching
export const getOrdersInDateRange = (startDate: Date, endDate: Date, tenantId: string = 'tenant-1'): Order[] => {
  // Create cache key
  const cacheKey = `${startDate.getTime()}-${endDate.getTime()}-${tenantId}`;
  
  // Check cache first
  if (_dateRangeCache.has(cacheKey)) {
    return _dateRangeCache.get(cacheKey)!;
  }
  
  // Create normalized dates for comparison (start of start date, end of end date)
  const normalizedStartDate = new Date(startDate);
  normalizedStartDate.setHours(0, 0, 0, 0);
  
  const normalizedEndDate = new Date(endDate);
  normalizedEndDate.setHours(23, 59, 59, 999);
  
  const orders = getMockOrders(); // Use lazy-loaded orders
  const result = orders.filter(order => {
    const orderDate = new Date(order.orderCreatedAt);
    return order.tenantId === tenantId &&
           orderDate >= normalizedStartDate && 
           orderDate <= normalizedEndDate;
  });
  
  // Cache the result
  _dateRangeCache.set(cacheKey, result);
  return result;
};

export const getStatsForDateRange = (startDate: Date, endDate: Date, tenantId: string = 'tenant-1'): StatsResponse => {
  const orders = getOrdersInDateRange(startDate, endDate, tenantId);
  const paidOrders = orders.filter(order => order.financialStatus === 'paid');
  
  // Calculate previous period for comparison
  const daysDiff = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1;
  const prevStartDate = new Date(startDate.getTime() - daysDiff * 24 * 60 * 60 * 1000);
  const prevEndDate = new Date(startDate.getTime() - 24 * 60 * 60 * 1000); // Day before start date
  const prevOrders = getOrdersInDateRange(prevStartDate, prevEndDate, tenantId);
  const prevPaidOrders = prevOrders.filter(order => order.financialStatus === 'paid');
  
  const totalRevenue = paidOrders.reduce((sum, order) => sum + order.totalPrice, 0);
  const prevRevenue = prevPaidOrders.reduce((sum, order) => sum + order.totalPrice, 0);
  
  const uniqueCustomers = new Set(paidOrders.map(order => order.customerId)).size;
  const prevUniqueCustomers = new Set(prevPaidOrders.map(order => order.customerId)).size;
  
  // Calculate percentage changes with fallbacks
  const revenueChange = prevRevenue > 0 ? ((totalRevenue - prevRevenue) / prevRevenue) * 100 : 
                       (totalRevenue > 0 ? 100 : 0);
  const ordersChange = prevPaidOrders.length > 0 ? ((paidOrders.length - prevPaidOrders.length) / prevPaidOrders.length) * 100 : 
                      (paidOrders.length > 0 ? 100 : 0);
  const customersChange = prevUniqueCustomers > 0 ? ((uniqueCustomers - prevUniqueCustomers) / prevUniqueCustomers) * 100 : 
                         (uniqueCustomers > 0 ? 100 : 0);
  
  return {
    totalRevenue: Math.round(totalRevenue * 100) / 100,
    totalOrders: paidOrders.length,
    totalCustomers: uniqueCustomers,
    revenueChange: Math.round(revenueChange * 10) / 10,
    ordersChange: Math.round(ordersChange * 10) / 10,
    customersChange: Math.round(customersChange * 10) / 10,
  };
};

export const getOrdersOverTime = (startDate: Date, endDate: Date, tenantId: string = 'tenant-1'): OrdersOverTimeResponse[] => {
  const orders = getOrdersInDateRange(startDate, endDate, tenantId);
  const paidOrders = orders.filter(order => order.financialStatus === 'paid');
  
  // Group by date
  const dailyData: { [key: string]: { count: number; revenue: number } } = {};
  
  paidOrders.forEach(order => {
    const dateKey = order.orderCreatedAt.toISOString().split('T')[0];
    if (!dailyData[dateKey]) {
      dailyData[dateKey] = { count: 0, revenue: 0 };
    }
    dailyData[dateKey].count++;
    dailyData[dateKey].revenue += order.totalPrice;
  });
  
  // Fill in missing dates with zero values
  const result: OrdersOverTimeResponse[] = [];
  const currentDate = new Date(startDate);
  
  while (currentDate <= endDate) {
    const dateKey = currentDate.toISOString().split('T')[0];
    result.push({
      date: dateKey,
      count: dailyData[dateKey]?.count || 0,
      revenue: Math.round((dailyData[dateKey]?.revenue || 0) * 100) / 100,
    });
    currentDate.setDate(currentDate.getDate() + 1);
  }
  
  return result;
};

export const getTopCustomers = (startDate: Date, endDate: Date, tenantId: string = 'tenant-1'): TopCustomersResponse[] => {
  const orders = getOrdersInDateRange(startDate, endDate, tenantId);
  const paidOrders = orders.filter(order => order.financialStatus === 'paid');
  
  // Group by customer
  const customerData: { [key: string]: { totalSpent: number; orderCount: number; customer: Customer } } = {};
  
  paidOrders.forEach(order => {
    if (order.customer) {
      const customerId = order.customer.id;
      if (!customerData[customerId]) {
        customerData[customerId] = {
          totalSpent: 0,
          orderCount: 0,
          customer: order.customer,
        };
      }
      customerData[customerId].totalSpent += order.totalPrice;
      customerData[customerId].orderCount++;
    }
  });
  
  // Sort by total spent and take top 5
  return Object.values(customerData)
    .sort((a, b) => b.totalSpent - a.totalSpent)
    .slice(0, 5)
    .map(data => ({
      name: `${data.customer.firstName} ${data.customer.lastName}`,
      email: data.customer.email || '',
      totalSpent: Math.round(data.totalSpent * 100) / 100,
      orderCount: data.orderCount,
    }));
};