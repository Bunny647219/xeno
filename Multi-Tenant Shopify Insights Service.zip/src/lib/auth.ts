import { AuthResponse, LoginCredentials, RegisterCredentials } from '../types';
import { mockUsers, mockTenants } from './mockData';

// Mock JWT token generation
const generateMockToken = (userId: string, tenantId: string): string => {
  const payload = {
    userId,
    tenantId,
    exp: Date.now() + 24 * 60 * 60 * 1000, // 24 hours
  };
  return btoa(JSON.stringify(payload));
};

// Mock authentication service
export class AuthService {
  private static readonly TOKEN_KEY = 'xeno_auth_token';
  private static readonly USER_KEY = 'xeno_user_data';

  static async login(credentials: LoginCredentials): Promise<AuthResponse> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Simple email/password validation
    const user = mockUsers.find(u => u.email === credentials.email);
    
    if (!user) {
      throw new Error('Invalid email or password');
    }

    // In a real app, you'd hash and compare passwords
    if (credentials.password !== 'demo123') {
      throw new Error('Invalid email or password');
    }

    const token = generateMockToken(user.id, user.tenantId);
    const tenant = mockTenants.find(t => t.id === user.tenantId);

    const authResponse: AuthResponse = {
      token,
      user: {
        id: user.id,
        email: user.email,
        tenantId: user.tenantId,
        shopDomain: tenant?.shopifyShopDomain || '',
      },
    };

    // Store in localStorage for persistence
    localStorage.setItem(this.TOKEN_KEY, token);
    localStorage.setItem(this.USER_KEY, JSON.stringify(authResponse.user));

    return authResponse;
  }

  static async register(credentials: RegisterCredentials): Promise<AuthResponse> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Check if user already exists
    const existingUser = mockUsers.find(u => u.email === credentials.email);
    if (existingUser) {
      throw new Error('User already exists with this email');
    }

    // Create new tenant and user (in reality, this would be stored in database)
    const newTenantId = `tenant-${Date.now()}`;
    const newUserId = `user-${Date.now()}`;

    const newTenant = {
      id: newTenantId,
      shopifyShopDomain: credentials.shopDomain,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const newUser = {
      id: newUserId,
      email: credentials.email,
      passwordHash: 'hashed-' + credentials.password,
      tenantId: newTenantId,
      tenant: newTenant,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    // Add to mock data (in memory only)
    mockTenants.push(newTenant);
    mockUsers.push(newUser);

    const token = generateMockToken(newUser.id, newUser.tenantId);

    const authResponse: AuthResponse = {
      token,
      user: {
        id: newUser.id,
        email: newUser.email,
        tenantId: newUser.tenantId,
        shopDomain: newTenant.shopifyShopDomain,
      },
    };

    // Store in localStorage
    localStorage.setItem(this.TOKEN_KEY, token);
    localStorage.setItem(this.USER_KEY, JSON.stringify(authResponse.user));

    return authResponse;
  }

  static logout(): void {
    localStorage.removeItem(this.TOKEN_KEY);
    localStorage.removeItem(this.USER_KEY);
  }

  static getCurrentUser(): AuthResponse['user'] | null {
    try {
      const userData = localStorage.getItem(this.USER_KEY);
      const token = localStorage.getItem(this.TOKEN_KEY);
      
      if (!userData || !token) {
        return null;
      }

      // Verify token is not expired
      const payload = JSON.parse(atob(token));
      if (payload.exp < Date.now()) {
        this.logout();
        return null;
      }

      return JSON.parse(userData);
    } catch {
      return null;
    }
  }

  static getToken(): string | null {
    return localStorage.getItem(this.TOKEN_KEY);
  }

  static isAuthenticated(): boolean {
    return this.getCurrentUser() !== null;
  }
}