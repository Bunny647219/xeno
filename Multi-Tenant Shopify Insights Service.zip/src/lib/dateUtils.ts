import { DateRange, DateRangePreset } from '../types';

export const getDateRangeForPreset = (preset: DateRangePreset): DateRange | null => {
  const now = new Date();
  // Set to end of today to include all of today's data
  const endDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);

  switch (preset) {
    case 'last7days':
      return {
        startDate: new Date(endDate.getTime() - 6 * 24 * 60 * 60 * 1000),
        endDate: endDate,
      };
    
    case 'last30days':
      return {
        startDate: new Date(endDate.getTime() - 29 * 24 * 60 * 60 * 1000),
        endDate: endDate,
      };
    
    case 'last90days':
      return {
        startDate: new Date(endDate.getTime() - 89 * 24 * 60 * 60 * 1000),
        endDate: endDate,
      };
    
    case 'thisMonth':
      return {
        startDate: new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0),
        endDate: endDate,
      };
    
    case 'lastMonth':
      const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1, 0, 0, 0, 0);
      const lastMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);
      return {
        startDate: lastMonth,
        endDate: lastMonthEnd,
      };
    
    case 'thisYear':
      return {
        startDate: new Date(now.getFullYear(), 0, 1, 0, 0, 0, 0),
        endDate: endDate,
      };
    
    case 'custom':
      return null; // Will be handled by date picker
    
    default:
      return null;
  }
};

export const formatDate = (date: Date): string => {
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
  });
};

export const formatDateFull = (date: Date): string => {
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
};

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
};

export const formatNumber = (num: number): string => {
  return new Intl.NumberFormat('en-US').format(num);
};

export const formatPercentage = (percentage: number): string => {
  const sign = percentage >= 0 ? '+' : '';
  return `${sign}${percentage.toFixed(1)}%`;
};