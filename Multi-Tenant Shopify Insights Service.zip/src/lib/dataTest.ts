// Test file to verify data generation - can be removed after testing
import { getStatsForDateRange, getOrdersInDateRange, debugOrderDistribution } from './mockData';
import { getDateRangeForPreset } from './dateUtils';

export const testDataGeneration = () => {
  console.log('=== Testing Data Generation ===');
  
  // Test debug function
  debugOrderDistribution();
  
  // Test last 7 days
  const last7Days = getDateRangeForPreset('last7days');
  if (last7Days) {
    const stats7 = getStatsForDateRange(last7Days.startDate, last7Days.endDate);
    const orders7 = getOrdersInDateRange(last7Days.startDate, last7Days.endDate);
    console.log('Last 7 days:', {
      orders: orders7.length,
      paidOrders: orders7.filter(o => o.financialStatus === 'paid').length,
      stats: stats7
    });
  }
  
  // Test last 30 days
  const last30Days = getDateRangeForPreset('last30days');
  if (last30Days) {
    const stats30 = getStatsForDateRange(last30Days.startDate, last30Days.endDate);
    const orders30 = getOrdersInDateRange(last30Days.startDate, last30Days.endDate);
    console.log('Last 30 days:', {
      orders: orders30.length,
      paidOrders: orders30.filter(o => o.financialStatus === 'paid').length,
      stats: stats30
    });
  }
  
  // Test this month
  const thisMonth = getDateRangeForPreset('thisMonth');
  if (thisMonth) {
    const statsMonth = getStatsForDateRange(thisMonth.startDate, thisMonth.endDate);
    const ordersMonth = getOrdersInDateRange(thisMonth.startDate, thisMonth.endDate);
    console.log('This month:', {
      orders: ordersMonth.length,
      paidOrders: ordersMonth.filter(o => o.financialStatus === 'paid').length,
      stats: statsMonth
    });
  }
};