// Configuration file for performance and debugging options

export const config = {
  // Set to true to enable heavy debug logging and test data generation
  // Only enable this when you need to debug data generation issues
  enableDebugMode: false,
  
  // Mock data cache settings
  enableDataCache: true,
  
  // Performance monitoring
  enablePerformanceLogging: false,
};

export const isDebugMode = () => {
  return config.enableDebugMode && process.env.NODE_ENV === 'development';
};

export const logPerformance = (operation: string, startTime: number) => {
  if (config.enablePerformanceLogging) {
    const endTime = performance.now();
    console.log(`⏱️ ${operation}: ${(endTime - startTime).toFixed(2)}ms`);
  }
};