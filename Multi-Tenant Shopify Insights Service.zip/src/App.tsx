import React, { useState, useEffect } from 'react';
import { AuthForm } from './components/AuthForm';
import { Dashboard } from './components/Dashboard';
import { AuthService } from './lib/auth';
import { XenoLogo } from './components/XenoLogo';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Quick check if user is already authenticated (synchronous)
    const startTime = performance.now();
    const user = AuthService.getCurrentUser();
    const endTime = performance.now();
    
    // Add minimal delay to prevent flash, but keep it fast
    const minDelay = Math.max(100, 200 - (endTime - startTime));
    
    const timer = setTimeout(() => {
      setIsAuthenticated(!!user);
      setIsLoading(false);
    }, minDelay);
    
    return () => clearTimeout(timer);
  }, []);

  const handleAuthSuccess = () => {
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="mb-4 animate-pulse">
            <XenoLogo size={48} showText={true} className="justify-center" />
          </div>
          <p className="text-gray-600">Loading Xeno Insights...</p>
          <div className="mt-2 w-32 h-1 bg-blue-200 rounded-full mx-auto overflow-hidden">
            <div className="h-full bg-blue-600 rounded-full animate-pulse w-full"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {isAuthenticated ? (
        <Dashboard onLogout={handleLogout} />
      ) : (
        <AuthForm onAuthSuccess={handleAuthSuccess} />
      )}
    </div>
  );
}