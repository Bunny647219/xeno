// Database Models Types
export interface Tenant {
  id: string;
  shopifyShopDomain: string;
  shopifyAccessToken?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface User {
  id: string;
  email: string;
  passwordHash: string;
  tenantId: string;
  tenant?: Tenant;
  createdAt: Date;
  updatedAt: Date;
}

export interface Customer {
  id: string;
  shopifyCustomerId: number;
  email?: string;
  firstName?: string;
  lastName?: string;
  totalSpent: number;
  tenantId: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Product {
  id: string;
  shopifyProductId: number;
  title: string;
  vendor?: string;
  price: number;
  tenantId: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Order {
  id: string;
  shopifyOrderId: number;
  totalPrice: number;
  financialStatus: 'pending' | 'paid' | 'refunded' | 'cancelled';
  orderCreatedAt: Date;
  customerId?: string;
  customer?: Customer;
  tenantId: string;
  createdAt: Date;
  updatedAt: Date;
}

// API Response Types
export interface AuthResponse {
  token: string;
  user: {
    id: string;
    email: string;
    tenantId: string;
    shopDomain: string;
  };
}

export interface StatsResponse {
  totalRevenue: number;
  totalOrders: number;
  totalCustomers: number;
  revenueChange: number;
  ordersChange: number;
  customersChange: number;
}

export interface OrdersOverTimeResponse {
  date: string;
  count: number;
  revenue: number;
}

export interface TopCustomersResponse {
  name: string;
  email: string;
  totalSpent: number;
  orderCount: number;
}

// Auth Types
export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterCredentials {
  email: string;
  password: string;
  shopDomain: string;
}

// Filter Types
export interface DateRange {
  startDate: Date;
  endDate: Date;
}

export type DateRangePreset = 'last7days' | 'last30days' | 'last90days' | 'thisMonth' | 'lastMonth' | 'thisYear' | 'custom';