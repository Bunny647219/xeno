
  # Multi-Tenant Shopify Insights Service

  This is a code bundle for Multi-Tenant Shopify Insights Service. The original project is available at https://www.figma.com/design/fqdjJ86qLKWVYNVun61ggj/Multi-Tenant-Shopify-Insights-Service.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  